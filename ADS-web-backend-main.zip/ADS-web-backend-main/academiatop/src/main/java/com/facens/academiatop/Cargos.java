package com.facens.academiatop;

public enum Cargos {
    INSTRUTOR,
    RECEPCIONISTA,
    LIMPEZA
}
