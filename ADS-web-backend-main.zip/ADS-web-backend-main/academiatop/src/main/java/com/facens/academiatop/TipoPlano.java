package com.facens.academiatop;

public enum TipoPlano {
    MENSAL, 
    TRIMESTRAL, 
    ANUAL
}
