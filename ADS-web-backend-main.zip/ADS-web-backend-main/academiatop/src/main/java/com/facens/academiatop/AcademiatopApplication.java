package com.facens.academiatop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AcademiatopApplication {

	public static void main(String[] args) {
		SpringApplication.run(AcademiatopApplication.class, args);
	}

}
